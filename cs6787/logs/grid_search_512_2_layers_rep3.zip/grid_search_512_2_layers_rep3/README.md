day_test_log_full_11-19_02-16-33.csv, day_log_11-19_02-16-33.csv
Namespace(batch_size=200, cuda=True, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=True, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --rotate_data


day_test_log_full_11-21_23-50-17.csv, day_log_11-21_23-50-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.05, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .05

fixed to aplly cw_weight to the original grad of last iter, rather than adjusted grad
day_test_log_full_11-22_00-04-20.csv, day_log_11-22_00-04-20.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

day_test_log_full_11-22_00-13-02.csv, day_log_11-22_00-13-02.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .5

set the cw_weight to the parameters after the first day
day_test_log_full_11-22_00-17-43.csv, day_log_11-22_00-17-43.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

set momentum to zero after first day
day_test_log_full_11-22_00-33-16.csv, day_log_11-22_00-33-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

day_test_log_full_11-23_16-26-49.csv, day_log_11-23_16-26-49.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .5

day_test_log_full_11-23_16-34-20.csv, day_log_11-23_16-34-20.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .9

day_test_log_full_11-23_16-42-03.csv, day_log_11-23_16-42-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=2.0, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 2.


day_test_log_full_11-24_23-36-59.csv, log_11-24_23-36-59.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30

day_test_log_full_11-25_00-00-03.csv, log_11-25_00-00-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=2048, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 2048

day_test_log_full_11-25_00-14-28.csv, log_11-25_00-14-28.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 1024

day_test_log_full_11-25_00-18-58.csv, log_11-25_00-18-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=20, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 20 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 1024

day_test_log_full_11-25_00-27-36.csv, log_11-25_00-27-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=20, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 20 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 512

day_test_log_full_11-25_00-53-06.csv, day_log_11-25_00-53-06.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=2048, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31 --num_hidden_units 2048

day_test_log_full_11-25_01-07-55.csv, day_log_11-25_01-07-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31 --use_last_loss

day_test_log_full_11-25_01-10-58.csv, day_log_11-25_01-10-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31

day_test_log_full_11-25_02-02-31.csv, day_log_11-25_02-02-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div

day_test_log_full_11-25_02-07-14.csv, day_log_11-25_02-07-14.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div

day_test_log_full_11-25_02-09-36.csv, day_log_11-25_02-09-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div


day_test_log_full_11-25_19-03-13_False_512.csv, day_log_11-25_19-03-13_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=100, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_day_resample 100

day_test_log_full_11-25_19-03-17_False_512.csv, day_log_11-25_19-03-17_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=10, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_day_resample 10

day_test_log_full_11-25_19-11-47_False_512.csv, day_log_11-25_19-11-47_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=10, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_day_resample 10

day_test_log_full_11-25_19-11-52_False_512.csv, day_log_11-25_19-11-52_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=100, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_day_resample 100

day_test_log_full_11-25_19-29-07_False_512.csv, day_log_11-25_19-29-07_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_19-29-08_False_512.csv, day_log_11-25_19-29-08_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_19-41-11.csv, log_11-25_19-41-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0.0, epoch_days_test=10.0, epochs=10, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days 0 --warm_epoch_days 30 --epochs_warm 10 --num_hidden_units 512 --use_last_loss --num_layers 4 --epoch_days_test 10


day_test_log_full_11-25_20-10-48_4.csv, day_log_11-25_20-10-48_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_20-10-51_2.csv, day_log_11-25_20-10-51_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-18-33_2.csv, day_log_11-25_20-18-33_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-19-54_4.csv, day_log_11-25_20-19-54_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_20-26-31_2.csv, day_log_11-25_20-26-31_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-29-21_4.csv, day_log_11-25_20-29-21_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_20-34-51_2.csv, day_log_11-25_20-34-51_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-38-47_4.csv, day_log_11-25_20-38-47_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_20-43-18_2.csv, day_log_11-25_20-43-18_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-48-14_4.csv, day_log_11-25_20-48-14_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_20-51-36_2.csv, day_log_11-25_20-51-36_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_20-57-42_4.csv, day_log_11-25_20-57-42_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-00-02_2.csv, day_log_11-25_21-00-02_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-07-13_4.csv, day_log_11-25_21-07-13_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-08-34_2.csv, day_log_11-25_21-08-34_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-16-44_4.csv, day_log_11-25_21-16-44_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-17-07_2.csv, day_log_11-25_21-17-07_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-25-47_2.csv, day_log_11-25_21-25-47_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-26-20_4.csv, day_log_11-25_21-26-20_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-34-27_2.csv, day_log_11-25_21-34-27_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-35-48_4.csv, day_log_11-25_21-35-48_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-42-43_2.csv, day_log_11-25_21-42-43_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-44-38_4.csv, day_log_11-25_21-44-38_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_21-51-31_2.csv, day_log_11-25_21-51-31_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_21-53-34_4.csv, day_log_11-25_21-53-34_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-00-06_2.csv, day_log_11-25_22-00-06_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-02-40_4.csv, day_log_11-25_22-02-40_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-07-53_2.csv, day_log_11-25_22-07-53_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-11-55_4.csv, day_log_11-25_22-11-55_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-15-54_2.csv, day_log_11-25_22-15-54_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-21-28_4.csv, day_log_11-25_22-21-28_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-24-04_2.csv, day_log_11-25_22-24-04_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-30-59_4.csv, day_log_11-25_22-30-59_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-32-24_2.csv, day_log_11-25_22-32-24_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-40-33_4.csv, day_log_11-25_22-40-33_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-40-44_2.csv, day_log_11-25_22-40-44_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-49-05_2.csv, day_log_11-25_22-49-05_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-50-05_4.csv, day_log_11-25_22-50-05_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_22-57-25_2.csv, day_log_11-25_22-57-25_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_22-59-30_4.csv, day_log_11-25_22-59-30_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-05-57_2.csv, day_log_11-25_23-05-57_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-08-53_4.csv, day_log_11-25_23-08-53_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-14-32_2.csv, day_log_11-25_23-14-32_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-18-20_4.csv, day_log_11-25_23-18-20_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-23-08_2.csv, day_log_11-25_23-23-08_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-27-43_4.csv, day_log_11-25_23-27-43_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-31-44_2.csv, day_log_11-25_23-31-44_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-37-09_4.csv, day_log_11-25_23-37-09_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-40-19_2.csv, day_log_11-25_23-40-19_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-46-41_4.csv, day_log_11-25_23-46-41_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-48-58_2.csv, day_log_11-25_23-48-58_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_23-56-14_4.csv, day_log_11-25_23-56-14_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_23-57-40_2.csv, day_log_11-25_23-57-40_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-05-50_4.csv, day_log_11-26_00-05-50_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-06-12_2.csv, day_log_11-26_00-06-12_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-14-54_2.csv, day_log_11-26_00-14-54_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-15-32_4.csv, day_log_11-26_00-15-32_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-23-29_2.csv, day_log_11-26_00-23-29_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-25-06_4.csv, day_log_11-26_00-25-06_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-32-06_2.csv, day_log_11-26_00-32-06_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-34-39_4.csv, day_log_11-26_00-34-39_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-40-54_2.csv, day_log_11-26_00-40-54_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-44-12_4.csv, day_log_11-26_00-44-12_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-49-40_2.csv, day_log_11-26_00-49-40_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_00-53-47_4.csv, day_log_11-26_00-53-47_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_00-58-31_2.csv, day_log_11-26_00-58-31_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-03-27_4.csv, day_log_11-26_01-03-27_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_01-07-23_2.csv, day_log_11-26_01-07-23_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-13-06_4.csv, day_log_11-26_01-13-06_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_01-16-15_2.csv, day_log_11-26_01-16-15_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-22-43_4.csv, day_log_11-26_01-22-43_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_01-25-01_2.csv, day_log_11-26_01-25-01_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-32-24_4.csv, day_log_11-26_01-32-24_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_01-33-52_2.csv, day_log_11-26_01-33-52_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-42-06_4.csv, day_log_11-26_01-42-06_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_01-42-37_2.csv, day_log_11-26_01-42-37_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-51-29_2.csv, day_log_11-26_01-51-29_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_01-51-49_4.csv, day_log_11-26_01-51-49_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-00-23_2.csv, day_log_11-26_02-00-23_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-01-31_4.csv, day_log_11-26_02-01-31_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-09-12_2.csv, day_log_11-26_02-09-12_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-11-15_4.csv, day_log_11-26_02-11-15_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-18-16_2.csv, day_log_11-26_02-18-16_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-21-00_4.csv, day_log_11-26_02-21-00_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-27-10_2.csv, day_log_11-26_02-27-10_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-30-31_4.csv, day_log_11-26_02-30-31_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-36-12_2.csv, day_log_11-26_02-36-12_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-40-23_4.csv, day_log_11-26_02-40-23_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-45-10_2.csv, day_log_11-26_02-45-10_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_02-50-11_4.csv, day_log_11-26_02-50-11_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_02-54-03_2.csv, day_log_11-26_02-54-03_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-00-00_4.csv, day_log_11-26_03-00-00_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-03-01_2.csv, day_log_11-26_03-03-01_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-09-47_4.csv, day_log_11-26_03-09-47_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-11-56_2.csv, day_log_11-26_03-11-56_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-19-10_4.csv, day_log_11-26_03-19-10_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-19-33_2.csv, day_log_11-26_03-19-33_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-27-44_2.csv, day_log_11-26_03-27-44_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-28-49_4.csv, day_log_11-26_03-28-49_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-36-06_2.csv, day_log_11-26_03-36-06_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-38-21_4.csv, day_log_11-26_03-38-21_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-44-35_2.csv, day_log_11-26_03-44-35_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-47-54_4.csv, day_log_11-26_03-47-54_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_03-53-07_2.csv, day_log_11-26_03-53-07_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_03-57-21_4.csv, day_log_11-26_03-57-21_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_04-01-37_2.csv, day_log_11-26_04-01-37_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-06-55_4.csv, day_log_11-26_04-06-55_4.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-26_04-10-08_2.csv, day_log_11-26_04-10-08_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-18-40_2.csv, day_log_11-26_04-18-40_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-27-44_2.csv, day_log_11-26_04-27-44_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-36-35_2.csv, day_log_11-26_04-36-35_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-45-17_2.csv, day_log_11-26_04-45-17_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_04-54-09_2.csv, day_log_11-26_04-54-09_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-02-46_2.csv, day_log_11-26_05-02-46_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-11-28_2.csv, day_log_11-26_05-11-28_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-20-21_2.csv, day_log_11-26_05-20-21_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-29-15_2.csv, day_log_11-26_05-29-15_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-38-11_2.csv, day_log_11-26_05-38-11_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-47-06_2.csv, day_log_11-26_05-47-06_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_05-55-08_2.csv, day_log_11-26_05-55-08_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-04-19_2.csv, day_log_11-26_06-04-19_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-12-32_2.csv, day_log_11-26_06-12-32_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-21-41_2.csv, day_log_11-26_06-21-41_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-30-19_2.csv, day_log_11-26_06-30-19_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-39-15_2.csv, day_log_11-26_06-39-15_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-48-08_2.csv, day_log_11-26_06-48-08_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_06-56-16_2.csv, day_log_11-26_06-56-16_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_07-05-25_2.csv, day_log_11-26_07-05-25_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-26_07-13-34_2.csv, day_log_11-26_07-13-34_2.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_last_loss

