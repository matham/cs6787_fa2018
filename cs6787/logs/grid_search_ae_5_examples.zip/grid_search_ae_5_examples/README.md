day_test_log_full_11-19_02-16-33.csv, day_log_11-19_02-16-33.csv
Namespace(batch_size=200, cuda=True, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=True, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --rotate_data


day_test_log_full_11-21_23-50-17.csv, day_log_11-21_23-50-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.05, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .05

fixed to aplly cw_weight to the original grad of last iter, rather than adjusted grad
day_test_log_full_11-22_00-04-20.csv, day_log_11-22_00-04-20.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

day_test_log_full_11-22_00-13-02.csv, day_log_11-22_00-13-02.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .5

set the cw_weight to the parameters after the first day
day_test_log_full_11-22_00-17-43.csv, day_log_11-22_00-17-43.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

set momentum to zero after first day
day_test_log_full_11-22_00-33-16.csv, day_log_11-22_00-33-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .2

day_test_log_full_11-23_16-26-49.csv, day_log_11-23_16-26-49.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .5

day_test_log_full_11-23_16-34-20.csv, day_log_11-23_16-34-20.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .9

day_test_log_full_11-23_16-42-03.csv, day_log_11-23_16-42-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=2.0, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 2.


day_test_log_full_11-24_23-36-59.csv, log_11-24_23-36-59.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30

day_test_log_full_11-25_00-00-03.csv, log_11-25_00-00-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=2048, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 2048

day_test_log_full_11-25_00-14-28.csv, log_11-25_00-14-28.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=10, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 1024

day_test_log_full_11-25_00-18-58.csv, log_11-25_00-18-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=20, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 20 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 1024

day_test_log_full_11-25_00-27-36.csv, log_11-25_00-27-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0, epoch_days_test=10.0, epochs=20, epochs_warm=5, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 20 --epoch_days_test 10 --warm_epoch_days 30 --num_hidden_units 512

day_test_log_full_11-25_00-53-06.csv, day_log_11-25_00-53-06.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=2048, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31 --num_hidden_units 2048

day_test_log_full_11-25_01-07-55.csv, day_log_11-25_01-07-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31 --use_last_loss

day_test_log_full_11-25_01-10-58.csv, day_log_11-25_01-10-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .31

day_test_log_full_11-25_02-02-31.csv, day_log_11-25_02-02-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div

day_test_log_full_11-25_02-07-14.csv, day_log_11-25_02-07-14.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div

day_test_log_full_11-25_02-09-36.csv, day_log_11-25_02-09-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --use_kl_div


day_test_log_full_11-25_19-03-13_False_512.csv, day_log_11-25_19-03-13_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=100, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_day_resample 100

day_test_log_full_11-25_19-03-17_False_512.csv, day_log_11-25_19-03-17_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=10, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_day_resample 10

day_test_log_full_11-25_19-11-47_False_512.csv, day_log_11-25_19-11-47_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=10, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_day_resample 10

day_test_log_full_11-25_19-11-52_False_512.csv, day_log_11-25_19-11-52_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=100, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_day_resample 100

day_test_log_full_11-25_19-29-07_False_512.csv, day_log_11-25_19-29-07_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight .3 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_19-29-08_False_512.csv, day_log_11-25_19-29-08_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --num_hidden_units 512 --use_last_loss --num_layers 4

day_test_log_full_11-25_19-41-11.csv, log_11-25_19-41-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=0.0, epoch_days_test=10.0, epochs=10, epochs_warm=10, include_invalid=False, lr=0.001, num_day_resample=0, num_hidden_units=512, num_layers=4, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 10 --epoch_days 0 --warm_epoch_days 30 --epochs_warm 10 --num_hidden_units 512 --use_last_loss --num_layers 4 --epoch_days_test 10

day_test_log_full_11-29_23-29-22_2.csv, day_log_11-29_23-29-22_2.csv
Namespace(ae=0.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae .5 --normalize

day_test_log_full_11-29_23-34-31_2.csv, day_log_11-29_23-34-31_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --use_last_loss --normalize

day_test_log_full_11-29_23-37-27_2.csv, day_log_11-29_23-37-27_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.3 --use_last_loss --normalize

day_test_log_full_11-29_23-42-21_2.csv, day_log_11-29_23-42-21_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.3 --use_last_loss --normalize --use_kl_div

day_test_log_full_11-29_23-50-38_2.csv, day_log_11-29_23-50-38_2.csv
Namespace(ae=0.9, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae .9 --normalize

day_test_log_full_11-29_23-51-45_2.csv, day_log_11-29_23-51-45_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.1 --use_last_loss --normalize

day_test_log_full_11-29_23-59-35_2.csv, day_log_11-29_23-59-35_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=10, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --use_last_loss --normalize --num_day_resample 10

day_test_log_full_11-29_23-59-47_2.csv, day_log_11-29_23-59-47_2.csv
Namespace(ae=0.9, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=10, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae .9 --normalize --num_day_resample 10

day_test_log_full_11-30_00-09-14_2.csv, day_log_11-30_00-09-14_2.csv
Namespace(ae=1.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=10, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 1.5 --normalize --num_day_resample 10

day_test_log_full_11-30_00-10-05_2.csv, day_log_11-30_00-10-05_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --use_last_loss --normalize --num_day_resample 5

day_test_log_full_11-30_00-17-09_2.csv, day_log_11-30_00-17-09_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=2, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --use_last_loss --normalize --num_day_resample 2

day_test_log_full_11-30_00-17-16_2.csv, day_log_11-30_00-17-16_2.csv
Namespace(ae=1.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 1.5 --normalize --num_day_resample 5


day_test_log_full_11-30_00-24-32_2.csv, day_log_11-30_00-24-32_2.csv
Namespace(ae=5.0, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 5 --normalize

day_test_log_full_11-30_00-25-42_2.csv, day_log_11-30_00-25-42_2.csv
Namespace(ae=1.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=2, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 1.5 --normalize --num_day_resample 2

day_test_log_full_11-30_00-29-49_2.csv, day_log_11-30_00-29-49_2.csv
Namespace(ae=4.0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.0 --ae 4 --normalize --num_day_resample 5

day_test_log_full_11-30_00-40-02_2.csv, day_log_11-30_00-40-02_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --use_last_loss --normalize

day_test_log_full_11-30_00-43-10_2.csv, day_log_11-30_00-43-10_2.csv
Namespace(ae=0.0, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.00 --normalize --num_day_resample 5

day_test_log_full_11-30_00-43-24_2.csv, day_log_11-30_00-43-24_2.csv
Namespace(ae=0.0, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.00 --normalize

day_test_log_full_11-30_00-47-35_2.csv, day_log_11-30_00-47-35_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --use_last_loss --normalize

day_test_log_full_11-30_00-50-13_2.csv, day_log_11-30_00-50-13_2.csv
Namespace(ae=0.02, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.02 --normalize

day_test_log_full_11-30_00-50-55_2.csv, day_log_11-30_00-50-55_2.csv
Namespace(ae=0.02, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.02 --normalize --num_day_resample 5

day_test_log_full_11-30_00-54-59_2.csv, day_log_11-30_00-54-59_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --use_last_loss --normalize

day_test_log_full_11-30_00-58-14_2.csv, day_log_11-30_00-58-14_2.csv
Namespace(ae=0.04, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.04 --normalize

day_test_log_full_11-30_00-59-10_2.csv, day_log_11-30_00-59-10_2.csv
Namespace(ae=0.04, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.04 --normalize --num_day_resample 5

day_test_log_full_11-30_01-02-53_2.csv, day_log_11-30_01-02-53_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --use_last_loss --normalize

day_test_log_full_11-30_01-06-17_2.csv, day_log_11-30_01-06-17_2.csv
Namespace(ae=0.06, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.06 --normalize

day_test_log_full_11-30_01-07-05_2.csv, day_log_11-30_01-07-05_2.csv
Namespace(ae=0.06, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.06 --normalize --num_day_resample 5

day_test_log_full_11-30_01-11-13_2.csv, day_log_11-30_01-11-13_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --use_last_loss --normalize

day_test_log_full_11-30_01-14-43_2.csv, day_log_11-30_01-14-43_2.csv
Namespace(ae=0.08, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.08 --normalize

day_test_log_full_11-30_01-15-20_2.csv, day_log_11-30_01-15-20_2.csv
Namespace(ae=0.08, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.08 --normalize --num_day_resample 5

day_test_log_full_11-30_01-19-34_2.csv, day_log_11-30_01-19-34_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --use_last_loss --normalize

day_test_log_full_11-30_01-23-43_2.csv, day_log_11-30_01-23-43_2.csv
Namespace(ae=0.1, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.10 --normalize

day_test_log_full_11-30_01-23-49_2.csv, day_log_11-30_01-23-49_2.csv
Namespace(ae=0.1, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.10 --normalize --num_day_resample 5

day_test_log_full_11-30_01-27-59_2.csv, day_log_11-30_01-27-59_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --use_last_loss --normalize

day_test_log_full_11-30_01-32-44_2.csv, day_log_11-30_01-32-44_2.csv
Namespace(ae=0.12, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.12 --normalize

day_test_log_full_11-30_01-33-03_2.csv, day_log_11-30_01-33-03_2.csv
Namespace(ae=0.12, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.12 --normalize --num_day_resample 5

day_test_log_full_11-30_01-36-24_2.csv, day_log_11-30_01-36-24_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --use_last_loss --normalize

day_test_log_full_11-30_01-41-56_2.csv, day_log_11-30_01-41-56_2.csv
Namespace(ae=0.14, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.14 --normalize

day_test_log_full_11-30_01-42-10_2.csv, day_log_11-30_01-42-10_2.csv
Namespace(ae=0.14, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.14 --normalize --num_day_resample 5

day_test_log_full_11-30_01-44-52_2.csv, day_log_11-30_01-44-52_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --use_last_loss --normalize

day_test_log_full_11-30_01-51-24_2.csv, day_log_11-30_01-51-24_2.csv
Namespace(ae=0.16, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.16 --normalize --num_day_resample 5

day_test_log_full_11-30_01-51-32_2.csv, day_log_11-30_01-51-32_2.csv
Namespace(ae=0.16, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.16 --normalize

day_test_log_full_11-30_01-53-12_2.csv, day_log_11-30_01-53-12_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --use_last_loss --normalize

day_test_log_full_11-30_02-00-06_2.csv, day_log_11-30_02-00-06_2.csv
Namespace(ae=0.18, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.18 --normalize

day_test_log_full_11-30_02-00-37_2.csv, day_log_11-30_02-00-37_2.csv
Namespace(ae=0.18, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.18 --normalize --num_day_resample 5

day_test_log_full_11-30_02-01-22_2.csv, day_log_11-30_02-01-22_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --use_last_loss --normalize

day_test_log_full_11-30_02-09-10_2.csv, day_log_11-30_02-09-10_2.csv
Namespace(ae=0.2, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.20 --normalize

day_test_log_full_11-30_02-09-54_2.csv, day_log_11-30_02-09-54_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --use_last_loss --normalize

day_test_log_full_11-30_02-10-13_2.csv, day_log_11-30_02-10-13_2.csv
Namespace(ae=0.2, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.20 --normalize --num_day_resample 5

day_test_log_full_11-30_02-18-12_2.csv, day_log_11-30_02-18-12_2.csv
Namespace(ae=0.22, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.22 --normalize

day_test_log_full_11-30_02-18-25_2.csv, day_log_11-30_02-18-25_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --use_last_loss --normalize

day_test_log_full_11-30_02-19-51_2.csv, day_log_11-30_02-19-51_2.csv
Namespace(ae=0.22, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.22 --normalize --num_day_resample 5

day_test_log_full_11-30_02-26-58_2.csv, day_log_11-30_02-26-58_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --use_last_loss --normalize

day_test_log_full_11-30_02-27-46_2.csv, day_log_11-30_02-27-46_2.csv
Namespace(ae=0.24, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.24 --normalize

day_test_log_full_11-30_02-29-29_2.csv, day_log_11-30_02-29-29_2.csv
Namespace(ae=0.24, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.24 --normalize --num_day_resample 5

day_test_log_full_11-30_02-35-40_2.csv, day_log_11-30_02-35-40_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --use_last_loss --normalize

day_test_log_full_11-30_02-37-17_2.csv, day_log_11-30_02-37-17_2.csv
Namespace(ae=0.26, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.26 --normalize

day_test_log_full_11-30_02-39-04_2.csv, day_log_11-30_02-39-04_2.csv
Namespace(ae=0.26, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.26 --normalize --num_day_resample 5

day_test_log_full_11-30_02-44-10_2.csv, day_log_11-30_02-44-10_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --use_last_loss --normalize

day_test_log_full_11-30_02-46-50_2.csv, day_log_11-30_02-46-50_2.csv
Namespace(ae=0.28, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.28 --normalize

day_test_log_full_11-30_02-48-43_2.csv, day_log_11-30_02-48-43_2.csv
Namespace(ae=0.28, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.28 --normalize --num_day_resample 5

day_test_log_full_11-30_02-52-51_2.csv, day_log_11-30_02-52-51_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --use_last_loss --normalize

day_test_log_full_11-30_02-56-29_2.csv, day_log_11-30_02-56-29_2.csv
Namespace(ae=0.3, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.30 --normalize

day_test_log_full_11-30_02-58-17_2.csv, day_log_11-30_02-58-17_2.csv
Namespace(ae=0.3, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.30 --normalize --num_day_resample 5

day_test_log_full_11-30_03-01-27_2.csv, day_log_11-30_03-01-27_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --use_last_loss --normalize

day_test_log_full_11-30_03-06-11_2.csv, day_log_11-30_03-06-11_2.csv
Namespace(ae=0.32, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.32 --normalize

day_test_log_full_11-30_03-07-44_2.csv, day_log_11-30_03-07-44_2.csv
Namespace(ae=0.32, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.32 --normalize --num_day_resample 5

day_test_log_full_11-30_03-10-07_2.csv, day_log_11-30_03-10-07_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --use_last_loss --normalize

day_test_log_full_11-30_03-14-37_2.csv, day_log_11-30_03-14-37_2.csv
Namespace(ae=0.34, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.34 --normalize

day_test_log_full_11-30_03-17-22_2.csv, day_log_11-30_03-17-22_2.csv
Namespace(ae=0.34, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.34 --normalize --num_day_resample 5

day_test_log_full_11-30_03-18-31_2.csv, day_log_11-30_03-18-31_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --use_last_loss --normalize

day_test_log_full_11-30_03-23-41_2.csv, day_log_11-30_03-23-41_2.csv
Namespace(ae=0.36, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.36 --normalize

day_test_log_full_11-30_03-27-15_2.csv, day_log_11-30_03-27-15_2.csv
Namespace(ae=0.36, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.36 --normalize --num_day_resample 5

day_test_log_full_11-30_03-27-16_2.csv, day_log_11-30_03-27-16_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --use_last_loss --normalize

day_test_log_full_11-30_03-32-52_2.csv, day_log_11-30_03-32-52_2.csv
Namespace(ae=0.38, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.38 --normalize

day_test_log_full_11-30_03-35-20_2.csv, day_log_11-30_03-35-20_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --use_last_loss --normalize

day_test_log_full_11-30_03-37-21_2.csv, day_log_11-30_03-37-21_2.csv
Namespace(ae=0.38, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.38 --normalize --num_day_resample 5

day_test_log_full_11-30_03-41-37_2.csv, day_log_11-30_03-41-37_2.csv
Namespace(ae=0.4, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.40 --normalize

day_test_log_full_11-30_03-42-33_2.csv, day_log_11-30_03-42-33_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --use_last_loss --normalize

day_test_log_full_11-30_03-45-42_2.csv, day_log_11-30_03-45-42_2.csv
Namespace(ae=0.4, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.40 --normalize --num_day_resample 5

day_test_log_full_11-30_03-49-53_2.csv, day_log_11-30_03-49-53_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --use_last_loss --normalize

day_test_log_full_11-30_03-50-46_2.csv, day_log_11-30_03-50-46_2.csv
Namespace(ae=0.42, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.42 --normalize

day_test_log_full_11-30_03-54-23_2.csv, day_log_11-30_03-54-23_2.csv
Namespace(ae=0.42, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.42 --normalize --num_day_resample 5

day_test_log_full_11-30_03-57-31_2.csv, day_log_11-30_03-57-31_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --use_last_loss --normalize

day_test_log_full_11-30_03-59-37_2.csv, day_log_11-30_03-59-37_2.csv
Namespace(ae=0.44, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.44 --normalize

day_test_log_full_11-30_04-03-21_2.csv, day_log_11-30_04-03-21_2.csv
Namespace(ae=0.44, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.44 --normalize --num_day_resample 5

day_test_log_full_11-30_04-04-47_2.csv, day_log_11-30_04-04-47_2.csv
Namespace(ae=0, batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --use_last_loss --normalize

day_test_log_full_11-30_04-09-02_2.csv, day_log_11-30_04-09-02_2.csv
Namespace(ae=0.46, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.46 --normalize

day_test_log_full_11-30_04-11-25_2.csv, day_log_11-30_04-11-25_2.csv
Namespace(ae=0.46, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.46 --normalize --num_day_resample 5

day_test_log_full_11-30_04-18-24_2.csv, day_log_11-30_04-18-24_2.csv
Namespace(ae=0.48, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.48 --normalize

day_test_log_full_11-30_04-19-54_2.csv, day_log_11-30_04-19-54_2.csv
Namespace(ae=0.48, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.48 --normalize --num_day_resample 5

day_test_log_full_11-30_04-27-19_2.csv, day_log_11-30_04-27-19_2.csv
Namespace(ae=0.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.50 --normalize

day_test_log_full_11-30_04-28-07_2.csv, day_log_11-30_04-28-07_2.csv
Namespace(ae=0.5, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.50 --normalize --num_day_resample 5

day_test_log_full_11-30_04-35-56_2.csv, day_log_11-30_04-35-56_2.csv
Namespace(ae=0.52, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.52 --normalize

day_test_log_full_11-30_04-37-00_2.csv, day_log_11-30_04-37-00_2.csv
Namespace(ae=0.52, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.52 --normalize --num_day_resample 5

day_test_log_full_11-30_04-45-02_2.csv, day_log_11-30_04-45-02_2.csv
Namespace(ae=0.54, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.54 --normalize

day_test_log_full_11-30_04-45-09_2.csv, day_log_11-30_04-45-09_2.csv
Namespace(ae=0.54, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.54 --normalize --num_day_resample 5

day_test_log_full_11-30_04-53-47_2.csv, day_log_11-30_04-53-47_2.csv
Namespace(ae=0.56, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.56 --normalize

day_test_log_full_11-30_04-54-03_2.csv, day_log_11-30_04-54-03_2.csv
Namespace(ae=0.56, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.56 --normalize --num_day_resample 5

day_test_log_full_11-30_05-02-12_2.csv, day_log_11-30_05-02-12_2.csv
Namespace(ae=0.58, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.58 --normalize

day_test_log_full_11-30_05-03-20_2.csv, day_log_11-30_05-03-20_2.csv
Namespace(ae=0.58, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.58 --normalize --num_day_resample 5

day_test_log_full_11-30_05-11-07_2.csv, day_log_11-30_05-11-07_2.csv
Namespace(ae=0.6, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.60 --normalize

day_test_log_full_11-30_05-11-33_2.csv, day_log_11-30_05-11-33_2.csv
Namespace(ae=0.6, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.60 --normalize --num_day_resample 5

day_test_log_full_11-30_05-19-53_2.csv, day_log_11-30_05-19-53_2.csv
Namespace(ae=0.62, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.62 --normalize

day_test_log_full_11-30_05-20-32_2.csv, day_log_11-30_05-20-32_2.csv
Namespace(ae=0.62, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.62 --normalize --num_day_resample 5

day_test_log_full_11-30_05-28-17_2.csv, day_log_11-30_05-28-17_2.csv
Namespace(ae=0.64, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.64 --normalize

day_test_log_full_11-30_05-29-44_2.csv, day_log_11-30_05-29-44_2.csv
Namespace(ae=0.64, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.64 --normalize --num_day_resample 5

day_test_log_full_11-30_05-37-18_2.csv, day_log_11-30_05-37-18_2.csv
Namespace(ae=0.66, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.66 --normalize

day_test_log_full_11-30_05-37-55_2.csv, day_log_11-30_05-37-55_2.csv
Namespace(ae=0.66, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.66 --normalize --num_day_resample 5

day_test_log_full_11-30_05-45-56_2.csv, day_log_11-30_05-45-56_2.csv
Namespace(ae=0.68, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.68 --normalize

day_test_log_full_11-30_05-46-51_2.csv, day_log_11-30_05-46-51_2.csv
Namespace(ae=0.68, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.68 --normalize --num_day_resample 5

day_test_log_full_11-30_05-54-21_2.csv, day_log_11-30_05-54-21_2.csv
Namespace(ae=0.7, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.70 --normalize

day_test_log_full_11-30_05-56-08_2.csv, day_log_11-30_05-56-08_2.csv
Namespace(ae=0.7, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.70 --normalize --num_day_resample 5

day_test_log_full_11-30_06-03-17_2.csv, day_log_11-30_06-03-17_2.csv
Namespace(ae=0.72, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.72 --normalize

day_test_log_full_11-30_06-04-24_2.csv, day_log_11-30_06-04-24_2.csv
Namespace(ae=0.72, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.72 --normalize --num_day_resample 5

day_test_log_full_11-30_06-12-30_2.csv, day_log_11-30_06-12-30_2.csv
Namespace(ae=0.74, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.74 --normalize

day_test_log_full_11-30_06-12-45_2.csv, day_log_11-30_06-12-45_2.csv
Namespace(ae=0.74, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.74 --normalize --num_day_resample 5

day_test_log_full_11-30_06-21-28_2.csv, day_log_11-30_06-21-28_2.csv
Namespace(ae=0.76, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.76 --normalize --num_day_resample 5

day_test_log_full_11-30_06-21-45_2.csv, day_log_11-30_06-21-45_2.csv
Namespace(ae=0.76, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.76 --normalize

day_test_log_full_11-30_06-30-33_2.csv, day_log_11-30_06-30-33_2.csv
Namespace(ae=0.78, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.78 --normalize --num_day_resample 5

day_test_log_full_11-30_06-30-59_2.csv, day_log_11-30_06-30-59_2.csv
Namespace(ae=0.78, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.78 --normalize

day_test_log_full_11-30_06-39-34_2.csv, day_log_11-30_06-39-34_2.csv
Namespace(ae=0.8, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.80 --normalize --num_day_resample 5

day_test_log_full_11-30_06-40-07_2.csv, day_log_11-30_06-40-07_2.csv
Namespace(ae=0.8, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.80 --normalize

day_test_log_full_11-30_06-48-31_2.csv, day_log_11-30_06-48-31_2.csv
Namespace(ae=0.82, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.82 --normalize

day_test_log_full_11-30_06-48-46_2.csv, day_log_11-30_06-48-46_2.csv
Namespace(ae=0.82, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.82 --normalize --num_day_resample 5

day_test_log_full_11-30_06-57-01_2.csv, day_log_11-30_06-57-01_2.csv
Namespace(ae=0.84, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.84 --normalize --num_day_resample 5

day_test_log_full_11-30_06-57-33_2.csv, day_log_11-30_06-57-33_2.csv
Namespace(ae=0.84, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.84 --normalize

day_test_log_full_11-30_07-05-25_2.csv, day_log_11-30_07-05-25_2.csv
Namespace(ae=0.86, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.86 --normalize --num_day_resample 5

day_test_log_full_11-30_07-06-34_2.csv, day_log_11-30_07-06-34_2.csv
Namespace(ae=0.86, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.86 --normalize

day_test_log_full_11-30_07-13-56_2.csv, day_log_11-30_07-13-56_2.csv
Namespace(ae=0.88, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.88 --normalize --num_day_resample 5

day_test_log_full_11-30_07-15-48_2.csv, day_log_11-30_07-15-48_2.csv
Namespace(ae=0.88, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.88 --normalize

day_test_log_full_11-30_07-22-12_2.csv, day_log_11-30_07-22-12_2.csv
Namespace(ae=0.9, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.90 --normalize --num_day_resample 5

day_test_log_full_11-30_07-24-25_2.csv, day_log_11-30_07-24-25_2.csv
Namespace(ae=0.9, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.90 --normalize

day_test_log_full_11-30_07-30-20_2.csv, day_log_11-30_07-30-20_2.csv
Namespace(ae=0.92, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.92 --normalize --num_day_resample 5

day_test_log_full_11-30_07-33-30_2.csv, day_log_11-30_07-33-30_2.csv
Namespace(ae=0.92, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.92 --normalize

day_test_log_full_11-30_07-38-45_2.csv, day_log_11-30_07-38-45_2.csv
Namespace(ae=0.94, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.94 --normalize --num_day_resample 5

day_test_log_full_11-30_07-42-39_2.csv, day_log_11-30_07-42-39_2.csv
Namespace(ae=0.94, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.94 --normalize

day_test_log_full_11-30_07-47-30_2.csv, day_log_11-30_07-47-30_2.csv
Namespace(ae=0.96, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.96 --normalize --num_day_resample 5

day_test_log_full_11-30_07-51-53_2.csv, day_log_11-30_07-51-53_2.csv
Namespace(ae=0.96, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.96 --normalize

day_test_log_full_11-30_07-56-25_2.csv, day_log_11-30_07-56-25_2.csv
Namespace(ae=0.98, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.98 --normalize --num_day_resample 5

day_test_log_full_11-30_08-00-57_2.csv, day_log_11-30_08-00-57_2.csv
Namespace(ae=0.98, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 0.98 --normalize

day_test_log_full_11-30_08-05-24_2.csv, day_log_11-30_08-05-24_2.csv
Namespace(ae=1.0, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=5, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 1.00 --normalize --num_day_resample 5

day_test_log_full_11-30_08-09-29_2.csv, day_log_11-30_08-09-29_2.csv
Namespace(ae=1.0, batch_size=200, cuda=True, cw_weight=0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, normalize=True, num_day_resample=0, num_hidden_units=512, num_layers=2, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --ae 1.00 --normalize

