day_test_log_full_11-23_18-30-55.csv, day_log_11-23_18-30-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00

day_test_log_full_11-23_18-38-18.csv, day_log_11-23_18-38-18.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.01, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.01

day_test_log_full_11-23_18-46-17.csv, day_log_11-23_18-46-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02

day_test_log_full_11-23_18-54-17.csv, day_log_11-23_18-54-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.03, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.03

day_test_log_full_11-23_19-02-23.csv, day_log_11-23_19-02-23.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04

day_test_log_full_11-23_19-10-25.csv, day_log_11-23_19-10-25.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.05, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.05

day_test_log_full_11-23_19-18-24.csv, day_log_11-23_19-18-24.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06

day_test_log_full_11-23_19-26-29.csv, day_log_11-23_19-26-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.07, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.07

day_test_log_full_11-23_19-34-01.csv, day_log_11-23_19-34-01.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08

day_test_log_full_11-23_19-42-05.csv, day_log_11-23_19-42-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.09, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.09

day_test_log_full_11-23_19-50-09.csv, day_log_11-23_19-50-09.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10

day_test_log_full_11-23_19-58-14.csv, day_log_11-23_19-58-14.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.11, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.11

day_test_log_full_11-23_20-06-25.csv, day_log_11-23_20-06-25.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12

day_test_log_full_11-23_20-14-30.csv, day_log_11-23_20-14-30.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.13, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.13

day_test_log_full_11-23_20-22-38.csv, day_log_11-23_20-22-38.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14

day_test_log_full_11-23_20-30-48.csv, day_log_11-23_20-30-48.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.15, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.15

day_test_log_full_11-23_20-38-56.csv, day_log_11-23_20-38-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16

day_test_log_full_11-23_20-47-03.csv, day_log_11-23_20-47-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.17, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.17

day_test_log_full_11-23_20-55-11.csv, day_log_11-23_20-55-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18

day_test_log_full_11-23_21-03-23.csv, day_log_11-23_21-03-23.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.19, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.19

day_test_log_full_11-23_21-11-29.csv, day_log_11-23_21-11-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20

day_test_log_full_11-23_21-19-34.csv, day_log_11-23_21-19-34.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.21, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.21

day_test_log_full_11-23_21-27-40.csv, day_log_11-23_21-27-40.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22

day_test_log_full_11-23_21-35-52.csv, day_log_11-23_21-35-52.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.23, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.23

day_test_log_full_11-23_21-44-00.csv, day_log_11-23_21-44-00.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24

day_test_log_full_11-23_21-52-06.csv, day_log_11-23_21-52-06.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.25, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.25

day_test_log_full_11-23_22-00-18.csv, day_log_11-23_22-00-18.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26

day_test_log_full_11-23_22-08-31.csv, day_log_11-23_22-08-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.27, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.27

day_test_log_full_11-23_22-16-39.csv, day_log_11-23_22-16-39.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28

day_test_log_full_11-23_22-24-52.csv, day_log_11-23_22-24-52.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.29, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.29

day_test_log_full_11-23_22-33-05.csv, day_log_11-23_22-33-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30

day_test_log_full_11-23_22-41-13.csv, day_log_11-23_22-41-13.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.31, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.31

day_test_log_full_11-23_22-49-22.csv, day_log_11-23_22-49-22.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32

day_test_log_full_11-23_22-57-31.csv, day_log_11-23_22-57-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.33, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.33

day_test_log_full_11-23_23-05-41.csv, day_log_11-23_23-05-41.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34

day_test_log_full_11-23_23-13-51.csv, day_log_11-23_23-13-51.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.35, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.35

day_test_log_full_11-23_23-22-01.csv, day_log_11-23_23-22-01.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36

day_test_log_full_11-23_23-30-19.csv, day_log_11-23_23-30-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.37, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.37

day_test_log_full_11-23_23-38-30.csv, day_log_11-23_23-38-30.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38

day_test_log_full_11-23_23-46-44.csv, day_log_11-23_23-46-44.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.39, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.39

day_test_log_full_11-23_23-54-55.csv, day_log_11-23_23-54-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40

day_test_log_full_11-24_00-03-09.csv, day_log_11-24_00-03-09.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.41, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.41

day_test_log_full_11-24_00-11-21.csv, day_log_11-24_00-11-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42

day_test_log_full_11-24_00-19-34.csv, day_log_11-24_00-19-34.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.43, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.43

day_test_log_full_11-24_00-27-08.csv, day_log_11-24_00-27-08.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44

day_test_log_full_11-24_00-35-18.csv, day_log_11-24_00-35-18.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.45, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.45

day_test_log_full_11-24_00-43-36.csv, day_log_11-24_00-43-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46

day_test_log_full_11-24_00-51-50.csv, day_log_11-24_00-51-50.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.47, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.47

day_test_log_full_11-24_01-00-02.csv, day_log_11-24_01-00-02.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48

day_test_log_full_11-24_01-08-19.csv, day_log_11-24_01-08-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.49, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.49

day_test_log_full_11-24_01-16-31.csv, day_log_11-24_01-16-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50

day_test_log_full_11-24_01-24-47.csv, day_log_11-24_01-24-47.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.51, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.51

day_test_log_full_11-24_01-33-00.csv, day_log_11-24_01-33-00.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52

day_test_log_full_11-24_01-41-22.csv, day_log_11-24_01-41-22.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.53, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.53

day_test_log_full_11-24_01-49-42.csv, day_log_11-24_01-49-42.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54

day_test_log_full_11-24_01-57-53.csv, day_log_11-24_01-57-53.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.55, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.55

day_test_log_full_11-24_02-06-06.csv, day_log_11-24_02-06-06.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56

day_test_log_full_11-24_02-14-16.csv, day_log_11-24_02-14-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.57, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.57

day_test_log_full_11-24_02-22-40.csv, day_log_11-24_02-22-40.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58

day_test_log_full_11-24_02-30-56.csv, day_log_11-24_02-30-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.59, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.59

day_test_log_full_11-24_02-39-10.csv, day_log_11-24_02-39-10.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60

day_test_log_full_11-24_02-47-29.csv, day_log_11-24_02-47-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.61, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.61

day_test_log_full_11-24_02-55-46.csv, day_log_11-24_02-55-46.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62

day_test_log_full_11-24_03-04-00.csv, day_log_11-24_03-04-00.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.63, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.63

day_test_log_full_11-24_03-11-33.csv, day_log_11-24_03-11-33.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64

day_test_log_full_11-24_03-19-48.csv, day_log_11-24_03-19-48.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.65, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.65

day_test_log_full_11-24_03-28-03.csv, day_log_11-24_03-28-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66

day_test_log_full_11-24_03-36-12.csv, day_log_11-24_03-36-12.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.67, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.67

day_test_log_full_11-24_03-44-31.csv, day_log_11-24_03-44-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68

day_test_log_full_11-24_03-52-48.csv, day_log_11-24_03-52-48.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.69, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.69

day_test_log_full_11-24_04-01-10.csv, day_log_11-24_04-01-10.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70

day_test_log_full_11-24_04-09-29.csv, day_log_11-24_04-09-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.71, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.71

day_test_log_full_11-24_04-17-45.csv, day_log_11-24_04-17-45.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72

day_test_log_full_11-24_04-25-58.csv, day_log_11-24_04-25-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.73, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.73

day_test_log_full_11-24_04-34-13.csv, day_log_11-24_04-34-13.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74

day_test_log_full_11-24_04-42-32.csv, day_log_11-24_04-42-32.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.75, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.75

day_test_log_full_11-24_04-50-43.csv, day_log_11-24_04-50-43.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76

day_test_log_full_11-24_04-59-01.csv, day_log_11-24_04-59-01.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.77, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.77

day_test_log_full_11-24_05-07-13.csv, day_log_11-24_05-07-13.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78

day_test_log_full_11-24_05-15-28.csv, day_log_11-24_05-15-28.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.79, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.79

day_test_log_full_11-24_05-23-47.csv, day_log_11-24_05-23-47.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80

day_test_log_full_11-24_05-32-05.csv, day_log_11-24_05-32-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.81, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.81

day_test_log_full_11-24_05-40-21.csv, day_log_11-24_05-40-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82

day_test_log_full_11-24_05-48-36.csv, day_log_11-24_05-48-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.83, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.83

day_test_log_full_11-24_05-56-56.csv, day_log_11-24_05-56-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84

day_test_log_full_11-24_06-05-10.csv, day_log_11-24_06-05-10.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.85, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.85

day_test_log_full_11-24_06-13-27.csv, day_log_11-24_06-13-27.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86

day_test_log_full_11-24_06-21-46.csv, day_log_11-24_06-21-46.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.87, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.87

day_test_log_full_11-24_06-30-05.csv, day_log_11-24_06-30-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88

day_test_log_full_11-24_06-38-27.csv, day_log_11-24_06-38-27.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.89, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.89

day_test_log_full_11-24_06-46-47.csv, day_log_11-24_06-46-47.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90

day_test_log_full_11-24_06-55-03.csv, day_log_11-24_06-55-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.91, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.91

day_test_log_full_11-24_07-03-24.csv, day_log_11-24_07-03-24.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92

day_test_log_full_11-24_07-11-42.csv, day_log_11-24_07-11-42.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.93, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.93

day_test_log_full_11-24_07-19-58.csv, day_log_11-24_07-19-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94

day_test_log_full_11-24_07-28-09.csv, day_log_11-24_07-28-09.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.95, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.95

day_test_log_full_11-24_07-36-24.csv, day_log_11-24_07-36-24.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96

day_test_log_full_11-24_07-44-43.csv, day_log_11-24_07-44-43.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.97, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.97

day_test_log_full_11-24_07-53-03.csv, day_log_11-24_07-53-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98

day_test_log_full_11-24_08-01-22.csv, day_log_11-24_08-01-22.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.99, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.99

day_test_log_full_11-24_08-09-42.csv, day_log_11-24_08-09-42.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00

day_test_log_full_11-24_08-18-03.csv, day_log_11-24_08-18-03.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.01, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.01

day_test_log_full_11-24_08-26-22.csv, day_log_11-24_08-26-22.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.02, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.02

day_test_log_full_11-24_08-34-39.csv, day_log_11-24_08-34-39.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.03, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.03

day_test_log_full_11-24_08-42-58.csv, day_log_11-24_08-42-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.04, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.04

day_test_log_full_11-24_08-51-15.csv, day_log_11-24_08-51-15.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.05, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.05

day_test_log_full_11-24_08-59-41.csv, day_log_11-24_08-59-41.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.06, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.06

day_test_log_full_11-24_09-08-01.csv, day_log_11-24_09-08-01.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.07, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.07

day_test_log_full_11-24_09-16-19.csv, day_log_11-24_09-16-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.08, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.08

day_test_log_full_11-24_09-24-39.csv, day_log_11-24_09-24-39.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.09, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.09

day_test_log_full_11-24_09-32-55.csv, day_log_11-24_09-32-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.1, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.10

day_test_log_full_11-24_09-40-21.csv, day_log_11-24_09-40-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.11, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.11

day_test_log_full_11-24_09-48-40.csv, day_log_11-24_09-48-40.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.12, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.12

day_test_log_full_11-24_09-57-01.csv, day_log_11-24_09-57-01.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.13, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.13

day_test_log_full_11-24_10-05-21.csv, day_log_11-24_10-05-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.14, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.14

day_test_log_full_11-24_10-13-45.csv, day_log_11-24_10-13-45.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.15, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.15

day_test_log_full_11-24_10-22-00.csv, day_log_11-24_10-22-00.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.16, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.16

day_test_log_full_11-24_10-30-22.csv, day_log_11-24_10-30-22.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.17, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.17

day_test_log_full_11-24_10-38-41.csv, day_log_11-24_10-38-41.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.18, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.18

day_test_log_full_11-24_10-46-59.csv, day_log_11-24_10-46-59.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.19, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.19

day_test_log_full_11-24_10-55-19.csv, day_log_11-24_10-55-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.2, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.20

day_test_log_full_11-24_11-03-38.csv, day_log_11-24_11-03-38.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.21, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.21

day_test_log_full_11-24_11-11-56.csv, day_log_11-24_11-11-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.22, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.22

day_test_log_full_11-24_11-20-13.csv, day_log_11-24_11-20-13.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.23, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.23

day_test_log_full_11-24_11-28-34.csv, day_log_11-24_11-28-34.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.24, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.24

day_test_log_full_11-24_11-36-53.csv, day_log_11-24_11-36-53.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.25, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.25

day_test_log_full_11-24_11-45-13.csv, day_log_11-24_11-45-13.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.26, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.26

day_test_log_full_11-24_11-53-36.csv, day_log_11-24_11-53-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.27, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.27

day_test_log_full_11-24_12-01-57.csv, day_log_11-24_12-01-57.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.28, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.28

day_test_log_full_11-24_12-10-17.csv, day_log_11-24_12-10-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.29, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.29

day_test_log_full_11-24_12-18-44.csv, day_log_11-24_12-18-44.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.3, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.30

day_test_log_full_11-24_12-26-27.csv, day_log_11-24_12-26-27.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.31, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.31

day_test_log_full_11-24_12-34-51.csv, day_log_11-24_12-34-51.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.32, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.32

day_test_log_full_11-24_12-43-11.csv, day_log_11-24_12-43-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.33, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.33

day_test_log_full_11-24_12-51-29.csv, day_log_11-24_12-51-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.34, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.34

day_test_log_full_11-24_12-59-46.csv, day_log_11-24_12-59-46.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.35, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.35

day_test_log_full_11-24_13-08-06.csv, day_log_11-24_13-08-06.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.36, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.36

day_test_log_full_11-24_13-16-25.csv, day_log_11-24_13-16-25.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.37, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.37

day_test_log_full_11-24_13-24-49.csv, day_log_11-24_13-24-49.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.38, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.38

day_test_log_full_11-24_13-33-07.csv, day_log_11-24_13-33-07.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.39, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.39

day_test_log_full_11-24_13-41-29.csv, day_log_11-24_13-41-29.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.4, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.40

day_test_log_full_11-24_13-49-48.csv, day_log_11-24_13-49-48.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.41, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.41

day_test_log_full_11-24_13-58-11.csv, day_log_11-24_13-58-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.42, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.42

day_test_log_full_11-24_14-06-32.csv, day_log_11-24_14-06-32.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.43, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.43

day_test_log_full_11-24_14-14-54.csv, day_log_11-24_14-14-54.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.44, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.44

day_test_log_full_11-24_14-23-17.csv, day_log_11-24_14-23-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.45, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.45

day_test_log_full_11-24_14-31-39.csv, day_log_11-24_14-31-39.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.46, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.46

day_test_log_full_11-24_14-39-58.csv, day_log_11-24_14-39-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.47, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.47

day_test_log_full_11-24_14-48-19.csv, day_log_11-24_14-48-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.48, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.48

day_test_log_full_11-24_14-56-43.csv, day_log_11-24_14-56-43.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.49, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.49

day_test_log_full_11-24_15-04-15.csv, day_log_11-24_15-04-15.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.5, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.50

day_test_log_full_11-24_15-12-36.csv, day_log_11-24_15-12-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.51, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.51

day_test_log_full_11-24_15-20-58.csv, day_log_11-24_15-20-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.52, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.52

day_test_log_full_11-24_15-29-19.csv, day_log_11-24_15-29-19.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.53, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.53

day_test_log_full_11-24_15-37-45.csv, day_log_11-24_15-37-45.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.54, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.54

day_test_log_full_11-24_15-46-11.csv, day_log_11-24_15-46-11.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.55, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.55

day_test_log_full_11-24_15-54-35.csv, day_log_11-24_15-54-35.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.56, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.56

day_test_log_full_11-24_16-02-56.csv, day_log_11-24_16-02-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.57, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.57

day_test_log_full_11-24_16-11-16.csv, day_log_11-24_16-11-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.58, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.58

day_test_log_full_11-24_16-19-36.csv, day_log_11-24_16-19-36.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.59, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.59

day_test_log_full_11-24_16-27-56.csv, day_log_11-24_16-27-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.6, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.60

day_test_log_full_11-24_16-36-25.csv, day_log_11-24_16-36-25.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.61, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.61

day_test_log_full_11-24_16-44-52.csv, day_log_11-24_16-44-52.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.62, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.62

day_test_log_full_11-24_16-53-16.csv, day_log_11-24_16-53-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.63, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.63

day_test_log_full_11-24_17-01-41.csv, day_log_11-24_17-01-41.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.64, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.64

day_test_log_full_11-24_17-10-09.csv, day_log_11-24_17-10-09.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.65, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.65

day_test_log_full_11-24_17-18-31.csv, day_log_11-24_17-18-31.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.66, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.66

day_test_log_full_11-24_17-26-58.csv, day_log_11-24_17-26-58.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.67, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.67

day_test_log_full_11-24_17-35-23.csv, day_log_11-24_17-35-23.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.68, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.68

day_test_log_full_11-24_17-43-44.csv, day_log_11-24_17-43-44.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.69, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.69

day_test_log_full_11-24_17-52-08.csv, day_log_11-24_17-52-08.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.7, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.70

day_test_log_full_11-24_18-00-35.csv, day_log_11-24_18-00-35.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.71, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.71

day_test_log_full_11-24_18-09-05.csv, day_log_11-24_18-09-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.72, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.72

day_test_log_full_11-24_18-17-33.csv, day_log_11-24_18-17-33.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.73, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.73

day_test_log_full_11-24_18-25-56.csv, day_log_11-24_18-25-56.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.74, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.74

day_test_log_full_11-24_18-34-24.csv, day_log_11-24_18-34-24.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.75, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.75

day_test_log_full_11-24_18-42-55.csv, day_log_11-24_18-42-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.76, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.76

day_test_log_full_11-24_18-51-25.csv, day_log_11-24_18-51-25.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.77, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.77

day_test_log_full_11-24_18-59-54.csv, day_log_11-24_18-59-54.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.78, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.78

day_test_log_full_11-24_19-08-17.csv, day_log_11-24_19-08-17.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.79, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.79

day_test_log_full_11-24_19-16-38.csv, day_log_11-24_19-16-38.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.8, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.80

day_test_log_full_11-24_19-25-08.csv, day_log_11-24_19-25-08.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.81, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.81

day_test_log_full_11-24_19-33-34.csv, day_log_11-24_19-33-34.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.82, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.82

day_test_log_full_11-24_19-41-59.csv, day_log_11-24_19-41-59.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.83, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.83

day_test_log_full_11-24_19-50-21.csv, day_log_11-24_19-50-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.84, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.84

day_test_log_full_11-24_19-58-52.csv, day_log_11-24_19-58-52.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.85, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.85

day_test_log_full_11-24_20-07-18.csv, day_log_11-24_20-07-18.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.86, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.86

day_test_log_full_11-24_20-15-40.csv, day_log_11-24_20-15-40.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.87, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.87

day_test_log_full_11-24_20-24-05.csv, day_log_11-24_20-24-05.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.88, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.88

day_test_log_full_11-24_20-32-28.csv, day_log_11-24_20-32-28.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.89, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.89

day_test_log_full_11-24_20-40-55.csv, day_log_11-24_20-40-55.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.9, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.90

day_test_log_full_11-24_20-49-16.csv, day_log_11-24_20-49-16.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.91, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.91

day_test_log_full_11-24_20-57-47.csv, day_log_11-24_20-57-47.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.92, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.92

day_test_log_full_11-24_21-06-20.csv, day_log_11-24_21-06-20.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.93, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.93

day_test_log_full_11-24_21-14-46.csv, day_log_11-24_21-14-46.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.94, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.94

day_test_log_full_11-24_21-22-12.csv, day_log_11-24_21-22-12.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.95, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.95

day_test_log_full_11-24_21-30-33.csv, day_log_11-24_21-30-33.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.96, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.96

day_test_log_full_11-24_21-38-54.csv, day_log_11-24_21-38-54.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.97, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.97

day_test_log_full_11-24_21-47-21.csv, day_log_11-24_21-47-21.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.98, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.98

day_test_log_full_11-24_21-55-52.csv, day_log_11-24_21-55-52.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.99, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.99

day_test_log_full_11-24_22-04-24.csv, day_log_11-24_22-04-24.csv
Namespace(batch_size=200, cuda=True, cw_weight=2.0, data='', epoch_days=10.0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 2.00

