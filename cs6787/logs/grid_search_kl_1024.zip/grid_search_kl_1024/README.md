day_test_log_full_11-25_02-29-52_False_512.csv, day_log_11-25_02-29-52_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_02-30-25_True_512.csv, day_log_11-25_02-30-25_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_02-37-21_True_1024.csv, day_log_11-25_02-37-21_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_02-37-55_False_1024.csv, day_log_11-25_02-37-55_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.00 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_02-46-07_True_512.csv, day_log_11-25_02-46-07_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_02-46-18_False_512.csv, day_log_11-25_02-46-18_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_02-54-15_False_1024.csv, day_log_11-25_02-54-15_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_02-54-58_True_1024.csv, day_log_11-25_02-54-58_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.02, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.02 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_03-02-30_False_512.csv, day_log_11-25_03-02-30_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_03-03-49_True_512.csv, day_log_11-25_03-03-49_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_03-10-52_False_1024.csv, day_log_11-25_03-10-52_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_03-12-33_True_1024.csv, day_log_11-25_03-12-33_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.04, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.04 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_03-19-16_False_512.csv, day_log_11-25_03-19-16_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_03-21-25_True_512.csv, day_log_11-25_03-21-25_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_03-27-49_False_1024.csv, day_log_11-25_03-27-49_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_03-30-18_True_1024.csv, day_log_11-25_03-30-18_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.06, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.06 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_03-36-19_False_512.csv, day_log_11-25_03-36-19_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_03-39-20_True_512.csv, day_log_11-25_03-39-20_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_03-44-48_False_1024.csv, day_log_11-25_03-44-48_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_03-48-13_True_1024.csv, day_log_11-25_03-48-13_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.08, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.08 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_03-53-30_False_512.csv, day_log_11-25_03-53-30_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_03-57-15_True_512.csv, day_log_11-25_03-57-15_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_04-02-10_False_1024.csv, day_log_11-25_04-02-10_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_04-06-17_True_1024.csv, day_log_11-25_04-06-17_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.1, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.10 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_04-10-43_False_512.csv, day_log_11-25_04-10-43_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_04-15-28_True_512.csv, day_log_11-25_04-15-28_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_04-19-25_False_1024.csv, day_log_11-25_04-19-25_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_04-24-34_True_1024.csv, day_log_11-25_04-24-34_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.12, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.12 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_04-28-10_False_512.csv, day_log_11-25_04-28-10_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_04-33-45_True_512.csv, day_log_11-25_04-33-45_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_04-36-58_False_1024.csv, day_log_11-25_04-36-58_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_04-42-53_True_1024.csv, day_log_11-25_04-42-53_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.14, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.14 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_04-45-49_False_512.csv, day_log_11-25_04-45-49_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_04-52-07_True_512.csv, day_log_11-25_04-52-07_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_04-54-36_False_1024.csv, day_log_11-25_04-54-36_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_05-01-15_True_1024.csv, day_log_11-25_05-01-15_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.16, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.16 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_05-03-20_False_512.csv, day_log_11-25_05-03-20_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_05-10-30_True_512.csv, day_log_11-25_05-10-30_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_05-12-07_False_1024.csv, day_log_11-25_05-12-07_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_05-19-39_True_1024.csv, day_log_11-25_05-19-39_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.18, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.18 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_05-20-58_False_512.csv, day_log_11-25_05-20-58_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_05-28-48_True_512.csv, day_log_11-25_05-28-48_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_05-29-44_False_1024.csv, day_log_11-25_05-29-44_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_05-38-01_True_1024.csv, day_log_11-25_05-38-01_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.2, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.20 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_05-38-37_False_512.csv, day_log_11-25_05-38-37_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_05-47-24_True_512.csv, day_log_11-25_05-47-24_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_05-47-28_False_1024.csv, day_log_11-25_05-47-28_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_05-55-27_True_1024.csv, day_log_11-25_05-55-27_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.22, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.22 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_05-55-50_False_512.csv, day_log_11-25_05-55-50_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_06-04-05_True_512.csv, day_log_11-25_06-04-05_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_06-04-28_False_1024.csv, day_log_11-25_06-04-28_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_06-12-44_True_1024.csv, day_log_11-25_06-12-44_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.24, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.24 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_06-13-06_False_512.csv, day_log_11-25_06-13-06_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_06-21-35_True_512.csv, day_log_11-25_06-21-35_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_06-21-45_False_1024.csv, day_log_11-25_06-21-45_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_06-29-31_False_512.csv, day_log_11-25_06-29-31_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_06-30-00_True_1024.csv, day_log_11-25_06-30-00_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.26, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.26 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_06-37-39_False_1024.csv, day_log_11-25_06-37-39_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_06-39-05_True_512.csv, day_log_11-25_06-39-05_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_06-45-56_False_512.csv, day_log_11-25_06-45-56_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_06-47-47_True_1024.csv, day_log_11-25_06-47-47_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.28, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.28 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_06-54-11_False_1024.csv, day_log_11-25_06-54-11_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_06-56-50_True_512.csv, day_log_11-25_06-56-50_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_07-02-38_False_512.csv, day_log_11-25_07-02-38_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_07-05-48_True_1024.csv, day_log_11-25_07-05-48_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.3, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.30 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_07-11-04_False_1024.csv, day_log_11-25_07-11-04_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_07-15-02_True_512.csv, day_log_11-25_07-15-02_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_07-19-40_False_512.csv, day_log_11-25_07-19-40_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_07-24-00_True_1024.csv, day_log_11-25_07-24-00_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.32, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.32 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_07-28-15_False_1024.csv, day_log_11-25_07-28-15_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_07-33-08_True_512.csv, day_log_11-25_07-33-08_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_07-36-54_False_512.csv, day_log_11-25_07-36-54_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_07-42-09_True_1024.csv, day_log_11-25_07-42-09_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.34, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.34 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_07-45-35_False_1024.csv, day_log_11-25_07-45-35_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_07-51-24_True_512.csv, day_log_11-25_07-51-24_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_07-54-16_False_512.csv, day_log_11-25_07-54-16_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_08-00-32_True_1024.csv, day_log_11-25_08-00-32_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.36, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.36 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_08-03-01_False_1024.csv, day_log_11-25_08-03-01_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_08-09-46_True_512.csv, day_log_11-25_08-09-46_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_08-11-46_False_512.csv, day_log_11-25_08-11-46_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_08-18-55_True_1024.csv, day_log_11-25_08-18-55_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.38, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.38 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_08-20-30_False_1024.csv, day_log_11-25_08-20-30_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_08-28-16_True_512.csv, day_log_11-25_08-28-16_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_08-29-18_False_512.csv, day_log_11-25_08-29-18_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_08-37-25_True_1024.csv, day_log_11-25_08-37-25_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.4, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.40 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_08-38-05_False_1024.csv, day_log_11-25_08-38-05_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_08-46-47_True_512.csv, day_log_11-25_08-46-47_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_08-46-50_False_512.csv, day_log_11-25_08-46-50_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_08-54-46_True_1024.csv, day_log_11-25_08-54-46_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.42, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.42 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_08-55-12_False_1024.csv, day_log_11-25_08-55-12_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_09-03-29_True_512.csv, day_log_11-25_09-03-29_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_09-03-52_False_512.csv, day_log_11-25_09-03-52_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_09-12-08_True_1024.csv, day_log_11-25_09-12-08_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.44, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.44 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_09-12-29_False_1024.csv, day_log_11-25_09-12-29_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_09-21-02_True_512.csv, day_log_11-25_09-21-02_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_09-21-10_False_512.csv, day_log_11-25_09-21-10_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_09-28-53_False_1024.csv, day_log_11-25_09-28-53_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_09-29-27_True_1024.csv, day_log_11-25_09-29-27_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.46, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.46 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_09-36-58_False_512.csv, day_log_11-25_09-36-58_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_09-38-31_True_512.csv, day_log_11-25_09-38-31_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_09-45-15_False_1024.csv, day_log_11-25_09-45-15_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_09-47-22_True_1024.csv, day_log_11-25_09-47-22_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.48, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.48 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_09-53-36_False_512.csv, day_log_11-25_09-53-36_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_09-56-28_True_512.csv, day_log_11-25_09-56-28_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_10-01-54_False_1024.csv, day_log_11-25_10-01-54_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_10-05-25_True_1024.csv, day_log_11-25_10-05-25_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.5, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.50 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_10-10-21_False_512.csv, day_log_11-25_10-10-21_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_10-14-31_True_512.csv, day_log_11-25_10-14-31_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_10-18-54_False_1024.csv, day_log_11-25_10-18-54_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_10-23-35_True_1024.csv, day_log_11-25_10-23-35_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.52, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.52 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_10-27-29_False_512.csv, day_log_11-25_10-27-29_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_10-32-40_True_512.csv, day_log_11-25_10-32-40_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_10-35-57_False_1024.csv, day_log_11-25_10-35-57_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_10-41-48_True_1024.csv, day_log_11-25_10-41-48_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.54, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.54 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_10-44-35_False_512.csv, day_log_11-25_10-44-35_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_10-51-01_True_512.csv, day_log_11-25_10-51-01_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_10-53-15_False_1024.csv, day_log_11-25_10-53-15_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_10-59-44_True_1024.csv, day_log_11-25_10-59-44_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.56, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.56 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_11-01-09_False_512.csv, day_log_11-25_11-01-09_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_11-08-48_True_512.csv, day_log_11-25_11-08-48_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_11-09-11_False_1024.csv, day_log_11-25_11-09-11_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_11-17-20_False_512.csv, day_log_11-25_11-17-20_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_11-17-53_True_1024.csv, day_log_11-25_11-17-53_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.58, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.58 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_11-25-35_False_1024.csv, day_log_11-25_11-25-35_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_11-27-00_True_512.csv, day_log_11-25_11-27-00_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_11-33-59_False_512.csv, day_log_11-25_11-33-59_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_11-36-00_True_1024.csv, day_log_11-25_11-36-00_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.6, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.60 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_11-42-24_False_1024.csv, day_log_11-25_11-42-24_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_11-45-08_True_512.csv, day_log_11-25_11-45-08_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_11-50-56_False_512.csv, day_log_11-25_11-50-56_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_11-54-09_True_1024.csv, day_log_11-25_11-54-09_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.62, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.62 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_11-59-26_False_1024.csv, day_log_11-25_11-59-26_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_12-03-19_True_512.csv, day_log_11-25_12-03-19_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_12-08-06_False_512.csv, day_log_11-25_12-08-06_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_12-12-24_True_1024.csv, day_log_11-25_12-12-24_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.64, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.64 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_12-16-42_False_1024.csv, day_log_11-25_12-16-42_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_12-21-38_True_512.csv, day_log_11-25_12-21-38_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_12-25-23_False_512.csv, day_log_11-25_12-25-23_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_12-30-48_True_1024.csv, day_log_11-25_12-30-48_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.66, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.66 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_12-34-06_False_1024.csv, day_log_11-25_12-34-06_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_12-39-53_True_512.csv, day_log_11-25_12-39-53_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_12-43-10_False_512.csv, day_log_11-25_12-43-10_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_12-48-53_True_1024.csv, day_log_11-25_12-48-53_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.68, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.68 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_12-51-53_False_1024.csv, day_log_11-25_12-51-53_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_12-58-09_True_512.csv, day_log_11-25_12-58-09_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_13-00-37_False_512.csv, day_log_11-25_13-00-37_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_13-07-16_True_1024.csv, day_log_11-25_13-07-16_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.7, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.70 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_13-09-20_False_1024.csv, day_log_11-25_13-09-20_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_13-16-41_True_512.csv, day_log_11-25_13-16-41_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_13-18-09_False_512.csv, day_log_11-25_13-18-09_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_13-25-52_True_1024.csv, day_log_11-25_13-25-52_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.72, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.72 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_13-26-57_False_1024.csv, day_log_11-25_13-26-57_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_13-35-17_True_512.csv, day_log_11-25_13-35-17_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_13-35-39_False_512.csv, day_log_11-25_13-35-39_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_13-44-29_True_1024.csv, day_log_11-25_13-44-29_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.74, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.74 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_13-44-32_False_1024.csv, day_log_11-25_13-44-32_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_13-52-21_False_512.csv, day_log_11-25_13-52-21_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_13-53-23_True_512.csv, day_log_11-25_13-53-23_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_14-00-28_False_1024.csv, day_log_11-25_14-00-28_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_14-02-23_True_1024.csv, day_log_11-25_14-02-23_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.76, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.76 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_14-08-46_False_512.csv, day_log_11-25_14-08-46_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_14-11-23_True_512.csv, day_log_11-25_14-11-23_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_14-17-11_False_1024.csv, day_log_11-25_14-17-11_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_14-20-20_True_1024.csv, day_log_11-25_14-20-20_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.78, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.78 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_14-25-39_False_512.csv, day_log_11-25_14-25-39_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_14-29-26_True_512.csv, day_log_11-25_14-29-26_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_14-34-10_False_1024.csv, day_log_11-25_14-34-10_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_14-38-29_True_1024.csv, day_log_11-25_14-38-29_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.8, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.80 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_14-42-44_False_512.csv, day_log_11-25_14-42-44_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_14-47-41_True_512.csv, day_log_11-25_14-47-41_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_14-51-12_False_1024.csv, day_log_11-25_14-51-12_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_14-56-48_True_1024.csv, day_log_11-25_14-56-48_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.82, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.82 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_14-59-54_False_512.csv, day_log_11-25_14-59-54_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_15-06-03_True_512.csv, day_log_11-25_15-06-03_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_15-08-37_False_1024.csv, day_log_11-25_15-08-37_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_15-15-15_True_1024.csv, day_log_11-25_15-15-15_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.84, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.84 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_15-17-21_False_512.csv, day_log_11-25_15-17-21_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_15-24-33_True_512.csv, day_log_11-25_15-24-33_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_15-26-02_False_1024.csv, day_log_11-25_15-26-02_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_15-33-49_True_1024.csv, day_log_11-25_15-33-49_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.86, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.86 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_15-34-45_False_512.csv, day_log_11-25_15-34-45_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_15-43-05_True_512.csv, day_log_11-25_15-43-05_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_15-43-27_False_1024.csv, day_log_11-25_15-43-27_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_15-52-15_True_1024.csv, day_log_11-25_15-52-15_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.88, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.88 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_15-52-18_False_512.csv, day_log_11-25_15-52-18_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_16-00-06_False_1024.csv, day_log_11-25_16-00-06_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_16-00-52_True_512.csv, day_log_11-25_16-00-52_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_16-08-00_False_512.csv, day_log_11-25_16-08-00_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_16-09-23_True_1024.csv, day_log_11-25_16-09-23_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.9, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.90 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_16-16-06_False_1024.csv, day_log_11-25_16-16-06_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_16-18-32_True_512.csv, day_log_11-25_16-18-32_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_16-24-18_False_512.csv, day_log_11-25_16-24-18_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_16-27-33_True_1024.csv, day_log_11-25_16-27-33_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.92, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.92 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_16-32-28_False_1024.csv, day_log_11-25_16-32-28_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_16-36-41_True_512.csv, day_log_11-25_16-36-41_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_16-40-53_False_512.csv, day_log_11-25_16-40-53_False_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00 --num_hidden_units 512 --use_last_loss

day_test_log_full_11-25_16-45-41_True_1024.csv, day_log_11-25_16-45-41_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.94, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.94 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_16-49-19_False_1024.csv, day_log_11-25_16-49-19_False_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=False, use_last_loss=True, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00 --num_hidden_units 1024 --use_last_loss

day_test_log_full_11-25_16-54-50_True_512.csv, day_log_11-25_16-54-50_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_17-03-49_True_1024.csv, day_log_11-25_17-03-49_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.96, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.96 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_17-12-44_True_512.csv, day_log_11-25_17-12-44_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_17-21-37_True_1024.csv, day_log_11-25_17-21-37_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=0.98, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 0.98 --num_hidden_units 1024 --use_kl_div

day_test_log_full_11-25_17-30-34_True_512.csv, day_log_11-25_17-30-34_True_512.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=512, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00 --num_hidden_units 512 --use_kl_div

day_test_log_full_11-25_17-39-27_True_1024.csv, day_log_11-25_17-39-27_True_1024.csv
Namespace(batch_size=200, cuda=True, cw_weight=1.0, data='', epoch_days=10.0, epoch_days_test=0, epochs=2, epochs_warm=10, include_invalid=False, lr=0.001, num_hidden_units=1024, predicted_features='temp-10pctl,temp-90pctl,temp-normal', randomize_samples=False, rotate_data=False, test=False, use_kl_div=True, use_last_loss=False, warm_epoch_days=30.0)
main.py --cuda --epochs 2 --epoch_days 10 --warm_epoch_days 30 --epochs_warm 10 --cw_weight 1.00 --num_hidden_units 1024 --use_kl_div

